ECE219 Project 3 Report Readme 

Team members:
Evelyn Chen         |704332587       |chenyiying@ucla.edu
Jack(Chenwei) Gong  |005025415       |cgpy7@ucla.edu
Haoxiang Zhang      |104278461	     |hxzhang@cs.ucla.edu
Jiuru Shao	    |204288539	     |jshao@cs.ucla.edu

Need to install/import the following for this project:

python3
panda
surprise
scikit-learn
numpy
matplotlib 
time
datetime



There's only one file called "project3.py" for this assignment. 

To run this assignment, run "python3 project3.py" in the terminal. Note that our code is only designed for python3 environment.

Due to the similarity of the functions as well as time complexity is concerned, we combined questions into chunks. To evaluate a specific question, for example, question 6, you will have to call the function named Q1to6(6), where 6 stands for problem 6 and passed into the function as a parameter.

Please refer to the spec and report for the description of each part. 
For parts that have more than one graph, please close the graph when you want the remaining code to run and other graphs to show up. 

Feel free to contact us by our emails if there is any issue with running our code. 
